#ifndef _APINT_ARITH_H_
#define _APINT_ARITH_H_

#include <stdio.h>
#include "ap_cint.h"

#define N 9

void apint_arith(signed char inA, signed char inB, signed char operation, signed char *out, signed char *rem);

#endif

